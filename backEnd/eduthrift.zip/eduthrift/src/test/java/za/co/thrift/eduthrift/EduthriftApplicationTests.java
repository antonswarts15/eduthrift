package za.co.thrift.eduthrift;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduthriftApplicationTests {

	@Test
	void contextLoads() {
	}

}
